const fs = require('fs');
const archiver = require('archiver');
const path = require('path');

const output = fs.createWriteStream(path.join(__dirname, 'backup.zip'));
const archive = archiver('zip', {
  zlib: { level: 9 }, // kompresi maksimal
});

output.on('close', () => {
  console.log(`✅ Backup selesai! Total size: ${archive.pointer()} bytes`);
});

archive.on('warning', (err) => {
  if (err.code === 'ENOENT') {
    console.warn('⚠️ File tidak ditemukan:', err);
  } else {
    throw err;
  }
});

archive.on('error', (err) => {
  throw err;
});

archive.pipe(output);

// Zip semua isi direktori saat ini, kecuali node_modules & backup.zip itu sendiri
archive.glob('**/*', {
  ignore: ['node_modules/**', 'backup.zip']
});

archive.finalize();