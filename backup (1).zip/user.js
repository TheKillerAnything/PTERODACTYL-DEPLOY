
module.exports = [
  ["admin", "rahasia123"],
  ["kiyy", "bangbot"],
  ["ikyy", "password123"]
];
